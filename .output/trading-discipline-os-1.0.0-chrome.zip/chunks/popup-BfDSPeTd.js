import{R as t,j as e,a as o,A as r}from"./App-C_c5IT9p.js";t.createRoot(document.getElementById("root")).render(e.jsx(o.StrictMode,{children:e.jsx(r,{})}));
